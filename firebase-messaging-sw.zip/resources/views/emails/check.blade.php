{!! $email_body !!}
